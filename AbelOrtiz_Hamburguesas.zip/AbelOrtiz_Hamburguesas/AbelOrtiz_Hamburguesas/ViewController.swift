//
//  ViewController.swift
//  AbelOrtiz_Hamburguesas
//
//  Created by Abel Ortiz Mayordomo on 04/12/16.
//  Copyright (c) 2016 Abel Ortiz Mayordomo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var labelPais: UILabel!
    @IBOutlet weak var labelHamburguesa: UILabel!
    var paises = ColeccionDePaises()
    var hamburguesas = ColeccionDeHamburguesas()
    var colores = Colores()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func cambioPaisHamburguesa() {
        labelPais.text = paises.obtenPais()
        labelHamburguesa.text = hamburguesas.obtenHamburguesa()
        view.backgroundColor = colores.regresarColorAleatorio()
    }
}

