//Velocimetro Digital

import UIKit

enum Velocidades : Int{
    case Apagado = 0,
    VelocidadBaja = 20,
    VelocidadMedia = 50,
    VelocidadAlta = 120
    
    init(velocidadInicial: Velocidades){
        self = velocidadInicial
    }
}

class Auto{
    var velocidad : Velocidades
    init(){
        velocidad = Velocidades(velocidadInicial: Velocidades.Apagado)
    }
    
    func cambioDeVelocidad() -> (actual: Int, velocidadCadena: String){
        var velocidadCadena : String
        switch velocidad{
        case .Apagado:
            println(velocidad.rawValue, "Apagado")
            velocidad = Velocidades.VelocidadBaja
            velocidadCadena = "Velocidad Baja"
        case .VelocidadBaja:
            velocidad = Velocidades.VelocidadMedia
            velocidadCadena = "Velocidad Media"
        case .VelocidadMedia:
            velocidad = Velocidades.VelocidadAlta
            velocidadCadena = "Velocidad Alta"
        case .VelocidadAlta:
            velocidad = Velocidades.VelocidadMedia
            velocidadCadena = "Velocidad Media"
        default:
            break
        }
        var actual = velocidad.rawValue
        return (actual, velocidadCadena)
    }
    
}

var auto = Auto()
for var i=0; i<20; i++ {
    println(auto.cambioDeVelocidad())
}